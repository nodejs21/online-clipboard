
var address = "";

var address_details = full_address.split(',<!--seperator-->');
if(address_details.length == 3){
    var address = address_details[0].split(',');
    address.push(address_details[1]);
    address.push(address_details[2]);
}else{
    var address = address_details;
}

if(document.getElementById("identity-add-new-address") != null){
    if(address.length == 7)
    {
        document.getElementById("enterAddressFullName").value = address[5];
        document.getElementById("enterAddressAddressLine1").value = address[0];
        document.getElementById("enterAddressAddressLine2").value = "";
        document.getElementById("enterAddressCity").value = address[1];
        document.getElementById("enterAddressStateOrRegion").value = address[2];
        document.getElementById("enterAddressPostalCode").value = address[3];
        document.getElementById("enterAddressPhoneNumber").value = address[6];
    }else if(address.length == 8){
        document.getElementById("enterAddressFullName").value = address[6];
        document.getElementById("enterAddressAddressLine1").value = address[0];
        document.getElementById("enterAddressAddressLine2").value = address[1];
        document.getElementById("enterAddressCity").value = address[2];
        document.getElementById("enterAddressStateOrRegion").value = address[3];
        document.getElementById("enterAddressPostalCode").value = address[4];
        document.getElementById("enterAddressPhoneNumber").value = address[7];
    }
    var first_name = address[5].split(' ')[0];
}else if(document.getElementById("address-ui-widgets-enterAddressFormContainer") != null){
    if(address.length == 7)
    {
        document.getElementById("address-ui-widgets-enterAddressFullName").value = address[5];
        document.getElementById("address-ui-widgets-enterAddressLine1").value = address[0];
        document.getElementById("address-ui-widgets-enterAddressLine2").value = "";
        document.getElementById("address-ui-widgets-enterAddressCity").value = address[1];
        document.getElementById("address-ui-widgets-enterAddressStateOrRegion").value = address[2];
        document.getElementById("address-ui-widgets-enterAddressPostalCode").value = address[3];
        document.getElementById("address-ui-widgets-enterAddressPhoneNumber").value = address[6];
    }else if(address.length == 8){
        document.getElementById("address-ui-widgets-enterAddressFullName").value = address[6];
        document.getElementById("address-ui-widgets-enterAddressLine1").value = address[0];
        document.getElementById("address-ui-widgets-enterAddressLine2").value = address[1];
        document.getElementById("address-ui-widgets-enterAddressCity").value = address[2];
        document.getElementById("address-ui-widgets-enterAddressStateOrRegion").value = address[3];
        document.getElementById("address-ui-widgets-enterAddressPostalCode").value = address[4];
        document.getElementById("address-ui-widgets-enterAddressPhoneNumber").value = address[7];
    }
    var first_name = address[5].split(' ')[0];
}