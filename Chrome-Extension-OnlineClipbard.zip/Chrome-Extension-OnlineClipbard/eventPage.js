
chrome.runtime.onMessage.addListener(
    function (request, sender, sendResponse) {
        // console.log(request.directive);
        switch (request.directive) {
            case "sendToClipboard": {
                console.log(`************${JSON.stringify(request.data, undefined, 2)}************`);
                sendToClipboard(request.data);
                // sendResponse("pasted");
                break;
            }
            case "copyFromClipboard": {
                copyFromClipboard();
            }
            default: {
                console.log("Unmatched request of '" + JSON.stringify(request, undefined, 2) + "' from script to background.js from " + JSON.stringify(sender, undefined, 2));
            }
        }
    }
);

function copyFromClipboard() {
    $.ajax({
        url: `https://yabbale-01.herokuapp.com/notes/get/Fjl15zdDY`,
        // url: `http://kl1p.com/W08L`,
        type: "GET",
        success: (data) => {
            try {
                // var parser = new DOMParser();
                // var doc = parser.parseFromString(data.toString(), "text/html");
                // var full_address = doc.querySelector("textarea[name=t]").value;
                // // var full_address = doc.getElementById(`notepad`).innerText;
                // console.log(`Full Address Response: ${full_address}`);
                // console.log(data);
                var full_address = data[0].content;
                fillAddress(full_address);
            } catch (exception) {
                console.log(`Exception from copyFromClipboard(): ${JSON.stringify(exception, undefined, 2)}`);
            }
        }
    });
};

function fillAddress(full_address) {
    try {
        console.log(full_address);
        var address = "";
        address_details = full_address.split(',<!--seperator-->');
        if(address_details.length == 3){
            address = address_details[0].split(',');
            address.push(address_details[1]);
            address.push(address_details[2]);
        }else{
            address = address_details;
        }
        chrome.tabs.query(
            { currentWindow: true, active: true },
            function (tabArray) {
                if(tabArray.length != 0) {
                    var tabId = tabArray[0].id;
                    var code = `if(document.getElementById("identity-add-new-address") != null){
                        if(${address.length == 7})
                        {
                            document.getElementById("enterAddressFullName").value = "${address[5]}";
                            document.getElementById("enterAddressAddressLine1").value = "${address[0]}";
                            document.getElementById("enterAddressAddressLine2").value = "${""}";
                            document.getElementById("enterAddressCity").value = "${address[1]}";
                            document.getElementById("enterAddressStateOrRegion").value = "${address[2]}";
                            document.getElementById("enterAddressPostalCode").value = "${address[3]}";
                            document.getElementById("enterAddressPhoneNumber").value = "${address[6]}";
                        }else if(${address.length == 8}){
                            document.getElementById("enterAddressFullName").value = "${address[6]}";
                            document.getElementById("enterAddressAddressLine1").value = "${address[0]}";
                            document.getElementById("enterAddressAddressLine2").value = "${address[1]}";
                            document.getElementById("enterAddressCity").value = "${address[2]}";
                            document.getElementById("enterAddressStateOrRegion").value = "${address[3]}";
                            document.getElementById("enterAddressPostalCode").value = "${address[4]}";
                            document.getElementById("enterAddressPhoneNumber").value = "${address[7]}";
                        }
                        var first_name = "${address[5].split(' ')[0]}";
                    }else if(document.getElementById("address-ui-widgets-enterAddressFormContainer") != null){
                        if(${address.length == 7})
                        {
                            document.getElementById("address-ui-widgets-enterAddressFullName").value = "${address[5]}";
                            document.getElementById("address-ui-widgets-enterAddressLine1").value = "${address[0]}";
                            document.getElementById("address-ui-widgets-enterAddressLine2").value = "${""}";
                            document.getElementById("address-ui-widgets-enterAddressCity").value = "${address[1]}";
                            document.getElementById("address-ui-widgets-enterAddressStateOrRegion").value = "${address[2]}";
                            document.getElementById("address-ui-widgets-enterAddressPostalCode").value = "${address[3]}";
                            document.getElementById("address-ui-widgets-enterAddressPhoneNumber").value = "${address[6]}";
                        }else if(${address.length == 8}){
                            document.getElementById("address-ui-widgets-enterAddressFullName").value = "${address[6]}";
                            document.getElementById("address-ui-widgets-enterAddressLine1").value = "${address[0]}";
                            document.getElementById("address-ui-widgets-enterAddressLine2").value = "${address[1]}";
                            document.getElementById("address-ui-widgets-enterAddressCity").value = "${address[2]}";
                            document.getElementById("address-ui-widgets-enterAddressStateOrRegion").value = "${address[3]}";
                            document.getElementById("address-ui-widgets-enterAddressPostalCode").value = "${address[4]}";
                            document.getElementById("address-ui-widgets-enterAddressPhoneNumber").value = "${address[7]}";
                        }
                        var first_name = "${address[5].split(' ')[0]}";}`;
                        chrome.tabs.executeScript(tabId, {code}, ()=>{
                            try{
                                console.log("I'm done with the final script.");
                            } catch(exception) {
                                console.log(`Exception while executing last script: ${exception}`);
                            }
                        });
                    }       
                }
            );
        } catch(exception) {
            console.log(`Exception from fillAddress(full_address): ${JSON.stringify(exception, undefined, 2)}`);
        }
    }
    
    function sendToClipboard(data) {
        var full_address = data.full_address;
        $.ajax({
            url: `https://yabbale-01.herokuapp.com/notes/push/Fjl15zdDY/`,
            type: 'POST',
            data: {
                'content': full_address
            },
            success: (data) => {
                try {
                    console.log(data);
                } catch (exception) {
                    console.log(`Exception from copyFromClipboard(): ${JSON.stringify(exception, undefined, 2)}`);
                }
            }
        })
        // chrome.tabs.create({
        //     url: `https://yabbale-01.herokuapp.com/notes/post/Fjl15zdDY/${full_address}`,
        //     // url: `http://kl1p.com/W08L`,
        //     selected: false
        // }
        // , function (tab) {
        //     console.log("Data pushed successfully");
        //     // var code = `document.querySelector("textarea[name=t]").value = "${full_address}";`;
        //     // // var code = `document.getElementById("notepad").innerText = "${full_address}";document.querySelector(\`a[class=\"menuitem save nocontent save-kl1p\"]\`).click();`;
        //     // chrome.tabs.executeScript(tab.id, { code }, () => {
        //     //     // console.log(`code: ${code}`);
        //     // });
        //     // setTimeout(() => {
        //     //     chrome.tabs.remove(tab.id);
        //     // }, 4000);
        // });
    }
    