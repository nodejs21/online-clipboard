
var domain = document.domain;
var rows = "";

var interval = setInterval(myMain, 1000);
window.addEventListener("load", myMain, false);


function myMain() {
    if(domain == "yaballe.com") {
        // console.log(`Domain: ${domain}`);
        rows = document.getElementById("sellings").getElementsByTagName("tr");
        for(i = 2; i<rows.length; i++){
            var but = document.getElementById("save_"+i);
            but.addEventListener("click", saved)
        };
    } else if (domain == "www.amazon.com") {
        // console.log(`Domain: ${domain}`);
        document.getElementById("load-address").addEventListener("click", fillAddress);
    }
}

function fillAddress(event) {
    var data = { }
    chrome.runtime.sendMessage({directive: "copyFromClipboard", data}, function(response) {
        console.log("Response from copyFromClipboard: "+response);
    });
}

function saved(event){
    if(document.querySelector("td[name='name']") == null || document.querySelector("td[name='address']") == null || document.querySelector("span[name='phone']") == null){
        newVersion = false;
    }
    else{
        newVersion = true; 
    }
    var target = event.target || event.srcElement;
    // console.log(target.id);
    // console.log(target.value);
    if(!newVersion){
        // console.log(rows[target.value].getElementsByClassName("text-center buyer_shipping_address_name ng-binding")[0].innerHTML.trim());
        // console.log(rows[target.value].getElementsByClassName("text-center buyer_shipping_address_phone ng-binding")[0].innerHTML.trim());
        var address = rows[target.value].getElementsByClassName("text-center buyer_shipping_address ng-binding")[0].innerHTML.trim().split(',');
    }else{
        // console.log(rows[target.value].querySelector("td[name='name']").innerHTML.trim());
        // console.log(rows[target.value].querySelector("span[name='phone']").innerHTML.trim());
        var address = rows[target.value].querySelector("td[name='address']").innerHTML.trim().split(',');
    }
    for(j = 0; j<address.length; j++){
        address[j] = address[j].trim();
        // console.log(address[j]);
    }
    if(!newVersion){
        var full_address = address.join()+",<!--seperator-->"+rows[target.value].getElementsByClassName("text-center buyer_shipping_address_name ng-binding")[0].innerHTML.trim()+",<!--seperator-->"+rows[target.value].getElementsByClassName("text-center buyer_shipping_address_phone ng-binding")[0].innerHTML.trim();
    }else{
        var full_address = address.join()+",<!--seperator-->"+rows[target.value].querySelector("td[name='name']").innerHTML.trim()+",<!--seperator-->"+rows[target.value].querySelector("span[name='phone']").innerHTML.trim();
    }
    // console.log(`**********************${full_address}**********************`);
    var data = { full_address }
    chrome.runtime.sendMessage({directive: "sendToClipboard", data}, function(response) {
        console.log("Response from message listener: "+response);
    });
    
}
